/*    */ package com.cabolabs.xre.core.execution;
/*    */ 
/*    */ public class VariablePointer
/*    */ {
/*    */   private VariableInstance variable;
/*    */ 
/*    */   public VariablePointer(VariableInstance var)
/*    */   {
/* 19 */     this.variable = var;
/*    */   }
/*    */ 
/*    */   public VariableInstance getVariable()
/*    */   {
/* 24 */     return this.variable;
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\Administrator\My Documents\workspace\rule-engine\lib\rule-engine-core.jar
 * Qualified Name:     com.cabolabs.xre.core.execution.VariablePointer
 * JD-Core Version:    0.6.2
 */